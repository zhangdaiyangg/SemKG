# SemKG-Selective artifact

Artifact revision: `2026-10-17-r6` (observed-versus-true read-set audit for SemKG-Noisy).
This directory is the reproducibility entry point for the paired discrete-event
simulation and executable contract-test sanity check.

## Reproduce

From the repository root run:

```powershell
powershell -ExecutionPolicy Bypass -File artifact/reproduce.ps1
```

The command regenerates the 40-scenario x 5-seed experiment, paired bootstrap,
sensitivity sweeps, figures, and 36 executable cases.
