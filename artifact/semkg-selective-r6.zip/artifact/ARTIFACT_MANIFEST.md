# SemKG-Selective anonymous artifact

Artifact revision: `2026-10-17-r6` (observed-versus-true read-set audit for SemKG-Noisy). The distributable bundle is `artifact/semkg-selective-r6.zip`.

This directory is the reproducibility entry point for the paired discrete-event
simulation and executable contract-test sanity check reported in the paper.

## Reproduce

From the repository root run:

```powershell
powershell -ExecutionPolicy Bypass -File artifact/reproduce.ps1
```

The command regenerates the 40-scenario x 5-seed main experiment, two-level
paired bootstrap, sensitivity sweeps, figures, and 36 executable cases.

## Audit files

- `results/raw_results.csv`: one row per scenario, seed, and protocol.
- `results/summary_wide.csv`: protocol means, including
  `commit_time_stale_accepted` and final direct violations.
- `results/paired_differences.csv`: scenario-then-seed bootstrap intervals.
- `results/historical_transitive_audit_s9_seed0.json`: preserved pre-fix trace.
- `results/semkg_perfect_trace_s9_seed0.json`: corrected rerun of the same case.
- `results/semkg_noisy_commit_audit_s2_seed1.json`: noisy-graph trace showing a missed `PriceUnit` read edge and one accepted true-stale read.
- `results/transitive_audit_summary.csv`: final transitive-staleness audit.
- `results/executable/by_category.csv`: direct-category and multi-hop outcomes.
- `results/experiment_manifest.json`: seeds, protocol order, noise, and cost model.
- `paper/main.tex`, `paper/main.pdf`: source and compiled 14-page LNCS manuscript.

The expected corrected audit has zero final transitive artifacts and zero
commit-time stale acceptances for SemKG-Perfect. SemKG-Noisy can accept a true
stale read when its graph omits that read edge; the audit trace makes the
observed-versus-true distinction explicit. The graph-cost coefficients are
sensitivity parameters, not deployment measurements.
