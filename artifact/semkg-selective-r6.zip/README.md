# SemKG-Selective artifact

This bundle contains the reproducible coordination simulator, result tables,
figures, tests, and frozen inputs for the SemKG artifact. It uses seeded
discrete-event simulation, typed contract-task edges, selective invalidation,
edge-level noisy observations, stale assumptions, and re-dispatch.

Run from this directory:

```powershell
python -m src.semkg_sim --out results --scenarios 40 --seeds 5
python -m src.analyze_results --results results --figures figures
python -m src.sensitivity
python -m src.executable_benchmark --out results\executable
```

The same sequence is available as `powershell -ExecutionPolicy Bypass -File artifact/reproduce.ps1`.

The SemKG artifact is publicly hosted at:
<https://github.com/zhangdaiyangg/SemKG>
