# SemKG-Selective artifact

This repository contains the reproducible coordination simulator, result tables, figures, and LNCS manuscript for:

**Versioned Semantic-Contract Invalidation in Parallel Software-Engineering Workflows**

Artifact revision: `2026-10-17-r6`; a distributable archive is provided at `artifact/semkg-selective-r6.zip`.

The artifact is an oracle-guided, seeded discrete-event simulation. It models repository task graphs, concrete semantic-contract mutations, typed contract--task edges, edge-level noisy graph observations, stale assumptions, selective invalidation, and re-dispatch. Graph-edge sampling uses a canonical edge order, so the seeded runs are reproducible across Python processes. It uses paired hash-keyed outcome draws so every protocol sees the same scenario and seed. Task tokens are a controlled proxy; graph construction, query, and coordination overhead are charged explicitly in total cost. In the noisy graph, true edges are retained with recall 0.82 and `round(0.08 * |E|)` extra edges are sampled, where `|E|` is the number of true edges; this is a construction ratio rather than a denominator over all candidate non-edges. Results report edge-level precision/recall separately from task-set precision/recall after traversal. The executable benchmark contains 36 generated contract-test cases: 30 one-hop cases across five semantic categories and six explicit three-hop cases. It invokes the same typed-graph traversal for the noisy condition.

## Reproduce the results

From this directory:

```powershell
python -m src.semkg_sim --out results --scenarios 40 --seeds 5
python -m src.analyze_results --results results --figures figures
python -m src.sensitivity
python -m src.executable_benchmark --out results\executable
```

The same sequence is available as `powershell -ExecutionPolicy Bypass -File artifact/reproduce.ps1`.

For SemKG-Noisy, commit validation uses the observed contract-read edges. The
simulator also retains the true read set for evaluation, so missed edges appear
as `commit_time_stale_accepted`; `results/semkg_noisy_commit_audit_s2_seed1.json`
is a concrete audit trace for this safety boundary.

The executable benchmark also writes `results/executable/by_category.csv`. The final transitive-staleness means are in `results/transitive_audit_summary.csv`. The historical pre-fix trace used to audit the former transitive diagnostic is preserved at `results/historical_transitive_audit_s9_seed0.json`; the corrected rerun of the same scenario is `results/semkg_perfect_trace_s9_seed0.json` and has an empty `transitive_ids` list. `results/summary_wide.csv` reports both `commit_time_stale_accepted` (stale attempts accepted at completion) and `semantic_violations` (final direct violations after the workflow).

This writes 1,600 protocol runs to `results/raw_results.csv`, scenario-level summaries and two-level paired bootstrap differences to `results/summary.csv` and `results/paired_differences.csv`, sensitivity summaries, and the architecture/results/trade-off figures to `figures/`.

## Build the manuscript

The LNCS source is in `paper/` and expects the generated figures one directory above it. After generating results and figures:

```powershell
Copy-Item figures\*.png paper\
Push-Location paper
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
Pop-Location
```

The current build produces `paper/main.pdf` in LNCS format. `paper/rendered/` contains page PNGs used for visual verification.

## Interpretation

The artifact reports eight protocols (Serial, Serial-Validated, NaiveParallel, StaticDAG, Version-Check, Global-Invalidate, SemKG-Perfect, and SemKG-Noisy), paired differences with scenario-then-seed bootstrap, typed-graph invalidation quality, sensitivity sweeps, category-level executable results, and an explicit multi-hop Python contract-test sanity check. The six direct cases within each category use distinct deterministic parameter values; the six multi-hop cases use distinct contract-version values and fixed graph seeds. The manuscript reports the generated workload, exact protocols, metrics, seeds, confidence intervals, graph overhead, and test outcomes.



