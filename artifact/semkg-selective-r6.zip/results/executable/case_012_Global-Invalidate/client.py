from contracts import ALLOWED_TRANSITIONS

def can_transition(old, new):
    return (old, new) in ALLOWED_TRANSITIONS
