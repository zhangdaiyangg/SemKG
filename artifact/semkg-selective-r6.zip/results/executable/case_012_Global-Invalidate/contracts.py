ALLOWED_TRANSITIONS = {("pending", "authorized")}
