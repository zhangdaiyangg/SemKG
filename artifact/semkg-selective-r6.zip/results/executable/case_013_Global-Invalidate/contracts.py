ALLOWED_TRANSITIONS = {("pending", "captured")}
