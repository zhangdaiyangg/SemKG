ALLOWED_TRANSITIONS = {("pending", "closed")}
