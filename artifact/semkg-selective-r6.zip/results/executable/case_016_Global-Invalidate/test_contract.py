import unittest
from client import can_transition

class ContractTest(unittest.TestCase):
    def test_transition_contract(self):
        self.assertTrue(can_transition("pending", "closed"))

if __name__ == "__main__": unittest.main()
