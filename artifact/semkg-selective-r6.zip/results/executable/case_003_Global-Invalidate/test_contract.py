import unittest
from decimal import Decimal
from client import to_minor_units, from_minor_units
from contracts import PRICE_SCALE

class ContractTest(unittest.TestCase):
    def test_round_trip_and_scale(self):
        self.assertEqual(to_minor_units("7.8"), int(Decimal("7.8") * PRICE_SCALE))
        self.assertEqual(from_minor_units(to_minor_units("7.8")), Decimal("7.8"))

if __name__ == "__main__": unittest.main()
