ERROR_MODE = "exception"
ERROR_TEXT = "failure-3"
