import unittest
from client import Store

class ContractTest(unittest.TestCase):
    def test_idempotency_contract(self):
        store = Store()
        store.process("request-2")
        store.process("request-2")
        self.assertEqual(store.count, 1)

if __name__ == "__main__": unittest.main()
