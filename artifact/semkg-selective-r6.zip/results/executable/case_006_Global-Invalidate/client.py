from contracts import ERROR_MODE, ERROR_TEXT

def handle_error():
    if ERROR_MODE == "exception":
        raise ValueError(ERROR_TEXT)
    return {"error": ERROR_TEXT}
