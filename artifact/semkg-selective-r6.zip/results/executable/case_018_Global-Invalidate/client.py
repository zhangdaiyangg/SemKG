from contracts import IDEMPOTENCY

class Store:
    def __init__(self):
        self.seen = set()
        self.count = 0

    def process(self, key):
        if IDEMPOTENCY == "deduplicate" and key in self.seen:
            return self.count
        self.seen.add(key)
        self.count += 1
        return self.count
