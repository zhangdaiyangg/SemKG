from decimal import Decimal
from contracts import PRICE_SCALE

def to_minor_units(amount):
    return int(Decimal(str(amount)) * PRICE_SCALE)

def from_minor_units(amount):
    return Decimal(str(amount)) / PRICE_SCALE
