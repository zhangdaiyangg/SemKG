ALLOWED_TRANSITIONS = set()  # stale assumption

def can_transition(old, new):
    return (old, new) in ALLOWED_TRANSITIONS
