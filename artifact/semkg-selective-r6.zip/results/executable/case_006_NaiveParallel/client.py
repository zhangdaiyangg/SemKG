ERROR_MODE = "value"
ERROR_TEXT = "stale"  # stale assumption

def handle_error():
    if ERROR_MODE == "exception":
        raise ValueError(ERROR_TEXT)
    return {"error": ERROR_TEXT}
