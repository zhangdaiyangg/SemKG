from decimal import Decimal
PRICE_SCALE = 1  # stale assumption

def to_minor_units(amount):
    return int(Decimal(str(amount)) * PRICE_SCALE)

def from_minor_units(amount):
    return Decimal(str(amount)) / PRICE_SCALE
