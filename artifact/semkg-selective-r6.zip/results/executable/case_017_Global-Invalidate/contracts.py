ALLOWED_TRANSITIONS = {("pending", "completed")}
