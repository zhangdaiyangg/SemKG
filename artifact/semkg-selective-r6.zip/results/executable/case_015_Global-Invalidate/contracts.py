ALLOWED_TRANSITIONS = {("pending", "refunded")}
