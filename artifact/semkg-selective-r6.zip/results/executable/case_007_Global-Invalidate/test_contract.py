import unittest
from client import handle_error

class ContractTest(unittest.TestCase):
    def test_error_contract(self):
        with self.assertRaisesRegex(ValueError, "failure-1"):
            handle_error()

if __name__ == "__main__": unittest.main()
