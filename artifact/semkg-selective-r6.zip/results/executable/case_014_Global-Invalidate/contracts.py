ALLOWED_TRANSITIONS = {("pending", "settled")}
